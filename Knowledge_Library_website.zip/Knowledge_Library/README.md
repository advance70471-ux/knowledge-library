# Knowledge Library

A responsive bilingual (Bangla/English) front-end website prototype.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser.

## Included
- Bangla/English language toggle
- Search and category/type filters
- Sample article and PDF listings
- Article reading modal
- Demo form to add an article or a PDF for the current browser session

## Important limitations
This is a front-end prototype, not a live publishing business. Added entries are held in page memory only and disappear when the page is refreshed. Uploaded PDFs are not sent to a server and are not publicly available to other visitors. There is no login, database, moderation, payment processing, ad network, or real earnings feature yet.

To launch publicly, the next stage needs secure hosting plus a backend/database, file storage, user/admin roles, content moderation, and payment/ad integrations. Payment and advertising accounts may have age and eligibility requirements; a parent or guardian should handle any required adult account setup. Never publish copyrighted PDFs without permission.
